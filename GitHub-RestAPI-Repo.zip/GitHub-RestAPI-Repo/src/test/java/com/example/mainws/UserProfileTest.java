package com.example.mainws;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import org.junit.jupiter.api.Test;
//import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.mainws.service.UserProfilemanageService;
import com.squareup.okhttp.OkHttpClient;

/**
 * @author s.bhaumik
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
//@DataJpaTest 
public class UserProfileTest {
	
@Autowired
TestRestTemplate testRestTemplate ;
@Autowired
private UserProfilemanageService updateProfilemngService ;

@Test
// Test case for storing data in H2-DB
public void tesaddUserProfile() throws IOException, InterruptedException
{
	//String gitUnameprofile=userRepositoryServive.getUserRepository(id);
	var request = HttpRequest.newBuilder().uri(URI.create("http://localhost:8080/adduserprofile"))
            .setHeader("Authorization", "Bearer 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")
            .setHeader("Content-Type", "application/json")
            .POST(BodyPublishers.ofString("[\r\n    {  \r\n    \"id\": \"5\",  \r\n    \"firstName\": \"David\",  "
            		+ "\r\n    \"surName\": \"Miranda\",  \r\n    \"position\": \"Senior Tech Support engineer\"  ,"
            		+ "\r\n    \"githubProfileurl\":\"https://github.com/Davidrep\"\r\n    \r\n}]"))
            .build();

    var response = HttpClient.newHttpClient().send(request, BodyHandlers.ofString());
    assertEquals(200, response.statusCode());
	
}
@Test
// Test case for User Git repository
public void testGitRepository() throws IOException, InterruptedException
{
	var request = HttpRequest.newBuilder().uri(URI.create("http://localhost:8080/users/5/repositories"))
            .setHeader("Authorization", "Bearer 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")
            .GET()
            .build();

    var response = HttpClient.newHttpClient().send(request, BodyHandlers.ofString());
    assertEquals(200, response.statusCode());
}
	
}
