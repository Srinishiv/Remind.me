/**
 * 
 */
package com.example.mainws.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mainws.model.UserEntityProfile;

/**
 * @author s.bhaumik
 *
 */
@Service
public class UserRepositoryService {

@Autowired
private UserProfileImpl userprofImpl;

// Get User-Git Hub profile
public String getUserRepository(int id)
{
	String gitProfile= userprofImpl.findById(id).get().getGithubProfileurl();
	String spgitUname[]=gitProfile.split("https://github.com/");
    String gitUname=spgitUname[1];
	return gitUname;
}

}
