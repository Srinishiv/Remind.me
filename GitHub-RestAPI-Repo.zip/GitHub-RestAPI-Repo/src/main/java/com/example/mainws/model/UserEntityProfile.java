/**
 * 
 */
package com.example.mainws.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author s.bhaumik
 *
 */
@Entity
@Table
public class UserEntityProfile {
	@Id
	@Column
	private int id;
	@Column
	private String firstName;
	@Column
	private String surName;
	@Column
	private String position;
	@Column
	private String githubProfileurl;
	/**
	 * @param id
	 * @param firstName
	 * @param surName
	 * @param position
	 * @param githubProfileurl
	 */
	
	public UserEntityProfile(int id, String firstName, String surName, String position, String githubProfileurl) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.surName = surName;
		this.position = position;
		this.githubProfileurl = githubProfileurl;
	}
	/**
	 * 
	 */
	public UserEntityProfile() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * @return the surName
	 */
	public String getSurName() {
		return surName;
	}
	/**
	 * @param surName the surName to set
	 */
	public void setSurName(String surName) {
		this.surName = surName;
	}
	/**
	 * @return the position
	 */
	public String getPosition() {
		return position;
	}
	/**
	 * @param position the position to set
	 */
	public void setPosition(String position) {
		this.position = position;
	}
	/**
	 * @return the githubProfileurl
	 */
	public String getGithubProfileurl() {
		return githubProfileurl;
	}
	/**
	 * @param githubProfileurl the githubProfileurl to set
	 */
	public void setGithubProfileurl(String githubProfileurl) {
		this.githubProfileurl = githubProfileurl;
	}
	@Override
	public String toString() {
		return "UserEntityProfile [id=" + id + ", firstName=" + firstName + ", surName=" + surName + ", position="
				+ position + ", githubProfileurl=" + githubProfileurl + "]";
	}
	

}
