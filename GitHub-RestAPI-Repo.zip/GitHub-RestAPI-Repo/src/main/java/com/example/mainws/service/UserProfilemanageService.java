/**
 * 
 */
package com.example.mainws.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.mainws.model.UserEntityProfile;

/**
 * @author s.bhaumik
 *
 */
@Service
public class UserProfilemanageService {
	
@Autowired
private UserProfileImpl userprofileImpl;

// To get all the User Git-Hub profile information
public List<UserEntityProfile> getAllUser()
{
	List<UserEntityProfile> userentProf = new ArrayList<>();
	userprofileImpl.findAll().forEach(userdata->userentProf.add(userdata));
	return userentProf;
}

// To get only one User Git-Hub profile information
public UserEntityProfile getSingleUser(int id)
{
	UserEntityProfile usersingleProfile;
	usersingleProfile= userprofileImpl.findById(id).get();
	return usersingleProfile;
}

// To store User Git -hub profile information

public void storeUserprofiledata(List<UserEntityProfile> usersingleProfile)
{
	
	userprofileImpl.saveAll(usersingleProfile);
}
// To remove single User-Git hub profile
public void removeSingleUserprofile(int id)
{
	userprofileImpl.deleteById(id);
}
// To update User Git-Hub profile data 
public void updateUserprofile(UserEntityProfile usersingleProfile )
{
	if(userprofileImpl.existsById(usersingleProfile.getId()))
	{
		userprofileImpl.save(usersingleProfile);
	}
	
}

}
