/**
 * 
 */
package com.example.mainws.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.mainws.model.UserEntityProfile;
import com.example.mainws.service.UserProfilemanageService;

/**
 * @author s.bhaumik
 *
 */
@RestController
public class UserProfileController {
	
@Autowired
private UserProfilemanageService userprofilemanageservice;

@PostMapping("/adduserprofile")
public void addUserProfile(@RequestBody List<UserEntityProfile> userentityprofile)
{
	
	userprofilemanageservice.storeUserprofiledata(userentityprofile);
}
@GetMapping("/alluserprofile")
public List<UserEntityProfile> getAllUserList()
{
	return userprofilemanageservice.getAllUser();
}

@GetMapping("/alluserprofile/{id}")
public UserEntityProfile getSingleuser(@PathVariable("id") int id)
{
	return userprofilemanageservice.getSingleUser(id);
}

@DeleteMapping("removespecuser/{id}")
public void removeSingleUser(@PathVariable("id") int id)
{
	userprofilemanageservice.removeSingleUserprofile(id);
}
@PutMapping("/modifyuser/{id}")
public void modifyUser(@RequestBody UserEntityProfile userentityprofile)
{
	userprofilemanageservice.updateUserprofile(userentityprofile);
}

}
