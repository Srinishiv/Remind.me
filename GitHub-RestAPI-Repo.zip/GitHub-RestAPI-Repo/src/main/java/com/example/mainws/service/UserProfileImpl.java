/**
 * 
 */
package com.example.mainws.service;

import org.springframework.data.repository.CrudRepository;

import com.example.mainws.model.UserEntityProfile;

/**
 * @author s.bhaumik
 *
 */
public interface UserProfileImpl extends CrudRepository<UserEntityProfile, Integer> {

}
