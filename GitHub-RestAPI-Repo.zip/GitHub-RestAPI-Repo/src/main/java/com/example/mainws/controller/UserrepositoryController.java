/**
 * 
 */
package com.example.mainws.controller;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse.BodyHandlers;
import java.util.ArrayList;
import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.example.mainws.service.UserRepositoryService;

/**
 * @author s.bhaumik
 *
 */
// Bearer personal access token = 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,Configurable Auth-token
 @RestController
 public class UserrepositoryController {

 @Autowired
 private UserRepositoryService userRepositoryServive;
	
 @GetMapping("/users/{id}/repositories")
 public ArrayList<Object> getRepository(@PathVariable("id") int id) throws IOException, InterruptedException, ParseException {
     String gitUnameprofile=userRepositoryServive.getUserRepository(id);
	 var request = HttpRequest.newBuilder().uri(URI.create("https://api.github.com/users/" +gitUnameprofile+"/repos"))
             .setHeader("Authorization","Bearer"+"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")
             .setHeader("Content-Type", "application/json")
             .GET()
             .build();
    
     var response = HttpClient.newHttpClient().send(request, BodyHandlers.ofString());
     JSONParser parser = new JSONParser(response.body().toString());
     ArrayList<Object> json = parser.parseArray();
     return json;
 } 
 
}
